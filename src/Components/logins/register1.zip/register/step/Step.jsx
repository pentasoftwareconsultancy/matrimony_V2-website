import React, { useState, useEffect } from "react";
import styles from "./Step.module.css";
import Profile from "../profile/Profile";
import FamilyBackground from "../familyback/Familyback";
import Education from "../education/Education";
import Horoscope from "../horoscope/Horoscope";

const Step = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isFormValid, setIsFormValid] = useState(false);

  // Initialize form data
  const initialFormData = {
    profile: {
      fullName: "",
      email: "",
      mobile: "",
      password: "",
      dob: "",
      city: "",
      gender: "",
    },
    familyBackground: {
      educationLevel: "",
      occupation: "",
      annualIncome: "",
      community: "",
      religion: "",
      timeOfBirth: "",
      cityOfBirth: "",
      manglik: "",
      gotra: "",
      ras: "",
      gan: "",
      nadi: "",
      charan: "",
      ageRangeFrom: "",
      ageRangeTo: "",
      partnerEducation: "",
      partnerLocation: "",
      partnerPackage: "",
      partnerAbout: "",
      fatherName: "",
      fatherOccupation: "",
      motherName: "",
      motherOccupation: "",
      numBrothers: "",
      numSisters: "",
      culturalValues: "",
      relationshipToProfile: "",
      aboutFamily: "",
    },
    education: {
      maritalStatus: "",
      numChildren: "",
      height: "",
      bodyType: "",
      weight: "",
      annualIncome: "",
      bloodGroup: "",
      companyName: "",
      complexion: "",
      diet: "",
      drink: "",
      educationDescription: "",
      educationField: "",
      occupationDescription: "",
      residencyStatus: "",
      smoke: "",
      educationLevel: "",
      occupation: "",
      specialCase: "",
    },
    horoscope: {
      profilePhoto: "",
      panCardNumber: "",
      companyId: "",
      aadharPassportType: "Aadhar Card",
      aadharNumber: "",
      facebookLink: "",
      instagramLink: "",
      linkedinLink: "",
    },
  };

  // Load saved data from localStorage
  const [formData, setFormData] = useState(() => {
    const savedData = localStorage.getItem("formData");
    return savedData ? JSON.parse(savedData) : initialFormData;
  });

  // Save form data to localStorage on every change
  useEffect(() => {
    localStorage.setItem("formData", JSON.stringify(formData));
  }, [formData]);

  // ✅ Validate form before submission (Prevent empty fields)
  const validateForm = () => {
    for (const section in formData) {
      for (const key in formData[section]) {
        if (typeof formData[section][key] === "string" && formData[section][key].trim() === "") {
          console.log(`❌ Empty field found: ${section} -> ${key}`);
          return false; // Stop if any field is empty
        }
      }
    }
    return true;
  };

  // ✅ Prevent submission if any field is empty
  const handleSubmit = () => {
    if (!validateForm()) {
      alert("⚠️ Please complete all steps before submitting.");
    } else {
      console.log("✅ Form Data Submitted:", formData);
      alert("🎉 Form submitted successfully!");
    }
  };

  // Define the steps
  const steps = [
    { id: 1, label: "Profile", component: <Profile formData={formData} setFormData={setFormData} setIsFormValid={setIsFormValid} /> },
    { id: 2, label: " Personal Details", component: <Education formData={formData} setFormData={setFormData} setIsFormValid={setIsFormValid} /> },
    { id: 3, label: "Family Background", component: <FamilyBackground formData={formData} setFormData={setFormData} setIsFormValid={setIsFormValid} /> },
    { id: 4, label: "Documents", component: <Horoscope formData={formData} setFormData={setFormData} setIsFormValid={setIsFormValid} /> },
  ];

  // Handle step changes
  const handleStepClick = (stepId) => {
    setCurrentStep(stepId);
  };

  return (
    <div className={styles.stepContainer}>
      <div className={styles.stepBar}>
        {steps.map((step) => (
          <div
            key={step.id}
            className={`${styles.step} ${currentStep === step.id ? styles.active : ""}`}
            onClick={() => handleStepClick(step.id)}
          >
            {currentStep === step.id ? "⭐" : "☆"} {step.label}
          </div>
        ))}
      </div>

      <div className={styles.stepContent}>
        {steps.find((step) => step.id === currentStep)?.component}
      </div>

      <div className={styles.stepActions}>
        <button className={styles.previous} onClick={() => setCurrentStep(currentStep - 1)} disabled={currentStep === 1}>
          Previous
        </button>
        {currentStep === steps.length ? (
          <button className={styles.submit} onClick={handleSubmit}>
            Submit
          </button>
        ) : (
          <button className={styles.next} onClick={() => setCurrentStep(currentStep + 1)}>
            Next
          </button>
        )}
      </div>
    </div>
  );
};

export default Step;
