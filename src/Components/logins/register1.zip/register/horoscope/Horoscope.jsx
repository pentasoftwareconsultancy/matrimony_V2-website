import React, { useState, useEffect } from "react";
import styles from "./Horoscope.module.css";

const Horoscope = ({ formData, setFormData }) => {
  const [horoscopeData, setHoroscopeData] = useState(formData.horoscope || {});

  // Load saved data from localStorage
  useEffect(() => {
    const savedData = localStorage.getItem("horoscopeData");
    if (savedData) {
      setHoroscopeData(JSON.parse(savedData));
    }
  }, []);

  // Save data to localStorage when horoscopeData changes
  useEffect(() => {
    localStorage.setItem("horoscopeData", JSON.stringify(horoscopeData));
    setFormData((prevData) => ({
      ...prevData,
      horoscope: horoscopeData,
    }));
  }, [horoscopeData, setFormData]);

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setHoroscopeData({
      ...horoscopeData,
      [name]: value,
    });
  };

  // Handle file uploads
  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setHoroscopeData({
      ...horoscopeData,
      [name]: files[0], // Store only file reference
    });
  };

  return (
    <form className={styles.form}>
      <div className={styles.main}>
        {/* Profile Photo */}
        <div className={styles.fieldGroup}>
          <label>Profile Photo*</label>
          <input
            type="file"
            name="profilePhoto"
            onChange={handleFileChange}
            className={styles.inputFile}
          />
          <span>{horoscopeData.profilePhoto ? horoscopeData.profilePhoto.name : "No file chosen"}</span>
        </div>

        {/* PAN Card Number */}
        <div className={styles.fieldGroup}>
          <label>PAN Card Number</label>
          <input
            type="text"
            name="panCardNumber"
            value={horoscopeData.panCardNumber || ""}
            onChange={handleInputChange}
            className={styles.inputText}
          />
        </div>

        {/* Company ID */}
        <div className={styles.fieldGroup}>
          <label>Company ID</label>
          <input
            type="file"
            name="companyId"
            onChange={handleFileChange}
            className={styles.inputFile}
          />
          <span>{horoscopeData.companyId ? horoscopeData.companyId.name : "No file chosen"}</span>
        </div>

        {/* Aadhar/Passport Type */}
        <div className={styles.fieldGroup}>
          <label>Aadhar/Passport Type*</label>
          <select
            name="aadharPassportType"
            value={horoscopeData.aadharPassportType || "Aadhar Card"}
            onChange={handleInputChange}
            className={styles.select}
          >
            <option value="Aadhar Card">Aadhar Card</option>
            <option value="Passport">Passport</option>
          </select>
        </div>

        {/* Aadhar Number */}
        <div className={styles.fieldGroup}>
          <label>Aadhar Number</label>
          <input
            type="text"
            name="aadharNumber"
            value={horoscopeData.aadharNumber || ""}
            onChange={handleInputChange}
            className={styles.inputText}
          />
        </div>

        {/* Aadhar Card Photo */}
        <div className={styles.fieldGroup}>
          <label>Aadhar Card Photo*</label>
          <input
            type="file"
            name="aadharPhoto"
            onChange={handleFileChange}
            className={styles.inputFile}
          />
          <span>{horoscopeData.aadharPhoto ? horoscopeData.aadharPhoto.name : "No file chosen"}</span>
        </div>

        {/* Social Links Section */}
        <div className={styles.Horoscope}>
          <div className={styles.fieldGroup}>
            <label>Facebook Profile Link</label>
            <input
              type="text"
              name="facebookLink"
              value={horoscopeData.facebookLink || ""}
              onChange={handleInputChange}
              className={styles.inputText}
            />
          </div>

          <div className={styles.fieldGroup}>
            <label>Instagram Profile Link</label>
            <input
              type="text"
              name="instagramLink"
              value={horoscopeData.instagramLink || ""}
              onChange={handleInputChange}
              className={styles.inputText}
            />
          </div>

          <div className={styles.fieldGroup}>
            <label>LinkedIn Profile Url</label>
            <input
              type="text"
              name="linkedinLink"
              value={horoscopeData.linkedinLink || ""}
              onChange={handleInputChange}
              className={styles.inputText}
            />
          </div>
        </div>
      </div>
    </form>
  );
};

export default Horoscope;
