import React, { useState, useEffect } from "react";
import styles from "./Familyback.module.css";

const Familyback = ({ formData, setFormData, setIsFormValid }) => {
  const [familyBackgroundData, setFamilyBackgroundData] = useState(
    formData.familyBackground || {
      // fatherName: "",
      fatherOccupation: "",
      motherName: "",
      motherOccupation: "",
      numBrothers: "",
      numSisters: "",
      culturalValues: "",
      relationshipToProfile: "",
      aboutFamily: "",
      community: "",
      religion: "",
      timeOfBirth: "",
      cityOfBirth: "",
      manglik: "",
      gotra: "",
      ras: "",
      gan: "",
      nadi: "",
      charan: "",
      ageRangeFrom: "",
      ageRangeTo: "",
      partnerEducation: "",
      partnerLocation: "",
      partnerPackage: "",
      partnerAbout: "",
    }
  );

  useEffect(() => {
    const isValid = Object.values(familyBackgroundData).every(
      (value) => value.trim() !== ""
    );
    setIsFormValid(isValid);
  }, [familyBackgroundData, setIsFormValid]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFamilyBackgroundData((prevData) => ({ ...prevData, [name]: value }));
    setFormData((prevFormData) => ({
      ...prevFormData,
      familyBackground: { ...prevFormData.familyBackground, [name]: value },
    }));
  };

  return (
    <div className={styles.educationContainer}>
      <h2>Family Information</h2>
      <div className={styles.family}>
        <div className={styles.main}>
          <label>
            Father Name*
            <input
              type="text"
              name="fatherName"
              value={familyBackgroundData.fatherName}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Father Occupation*
            <input
              type="text"
              name="fatherOccupation"
              value={familyBackgroundData.fatherOccupation}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Mother Name*
            <input
              type="text"
              name="motherName"
              value={familyBackgroundData.motherName}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Mother Occupation*
            <input
              type="text"
              name="motherOccupation"
              value={familyBackgroundData.motherOccupation}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            How Many Brothers*
            <input
              type="number"
              name="numBrothers"
              value={familyBackgroundData.numBrothers}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            How Many Sisters*
            <input
              type="number"
              name="numSisters"
              value={familyBackgroundData.numSisters}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Cultural / Family Value*
            <input
              type="text"
              name="culturalValues"
              value={familyBackgroundData.culturalValues}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Relationship to Profile*
            <input
              type="text"
              name="relationshipToProfile"
              value={familyBackgroundData.relationshipToProfile}
              onChange={handleChange}
              required
            />
          </label>
        </div>

        <div className={styles.containar}>
          <label>
            About Yourself & Family*
            <textarea
              name="aboutFamily"
              value={familyBackgroundData.aboutFamily}
              onChange={handleChange}
              required
            ></textarea>
          </label>
        </div>
      </div>

      <h2>Patrika / Astrology Details</h2>
      <div className={styles.family}>
        <div className={styles.patrika}>
          <label>
            Community / Mother Tongue*
            <input
              type="text"
              name="community"
              value={familyBackgroundData.community}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Religion*
            <input
              type="text"
              name="religion"
              value={familyBackgroundData.religion}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Time of Birth*
            <input
              type="text"
              name="timeOfBirth"
              value={familyBackgroundData.timeOfBirth}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            City/Town of Birth*
            <input
              type="text"
              name="cityOfBirth"
              value={familyBackgroundData.cityOfBirth}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Are you Manglik?
            <select
              name="manglik"
              value={familyBackgroundData.manglik}
              onChange={handleChange}
              required
            >
              <option value="">Select</option>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
              <option value="Don't Know">Don't Know</option>
            </select>
          </label>

          <label>
            Gotra
            <input
              type="text"
              name="gotra"
              value={familyBackgroundData.gotra}
              onChange={handleChange}
            />
          </label>

          <label>
            Ras
            <input
              type="text"
              name="ras"
              value={familyBackgroundData.ras}
              onChange={handleChange}
            />
          </label>

          <label>
            Gan
            <input
              type="text"
              name="gan"
              value={familyBackgroundData.gan}
              onChange={handleChange}
            />
          </label>

          <label>
            Nadi
            <input
              type="text"
              name="nadi"
              value={familyBackgroundData.nadi}
              onChange={handleChange}
            />
          </label>

          <label>
            Charan
            <input
              type="text"
              name="charan"
              value={familyBackgroundData.charan}
              onChange={handleChange}
            />
          </label>
        </div>
      </div>

      <h2>More About Your Ideal Partner</h2>
      <div className={styles.family}>
        <div className={styles.main}>
          <label>
            Age Range*
            <div className={styles.ageRange}>
              <input
                type="number"
                name="ageRangeFrom"
                value={familyBackgroundData.ageRangeFrom}
                onChange={handleChange}
                required
                placeholder="From"
              />
              <input
                type="number"
                name="ageRangeTo"
                value={familyBackgroundData.ageRangeTo}
                onChange={handleChange}
                required
                placeholder="To"
              />
            </div>
          </label>

          <label>
            Education*
            <input
              type="text"
              name="partnerEducation"
              value={familyBackgroundData.partnerEducation}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Location
            <input
              type="text"
              name="partnerLocation"
              value={familyBackgroundData.partnerLocation}
              onChange={handleChange}
            />
          </label>

          <label>
            Package
            <input
              type="text"
              name="partnerPackage"
              value={familyBackgroundData.partnerPackage}
              onChange={handleChange}
            />
          </label>
        </div>

        <label>
          About Your Ideal Partner*
          <textarea
            name="partnerAbout"
            value={familyBackgroundData.partnerAbout}
            onChange={handleChange}
            required
          ></textarea>
        </label>
      </div>
    </div>
  );
};

export default Familyback;
